package NewPackage;
import Test.*;
import java.util.*;
class InvalidException extends Exception{
	InvalidException(){
		super("passenger not found");
	}
}

class Flight{
	String fname,lname,mname,dest,mno;
	int pid;
	Scanner sc=new Scanner(System.in);
	void getdata()
	{
	System.out.print("\n\n enter your first name=");
	fname=sc.next();
	System.out.print(" enter your middle name=");
	mname=sc.next();
	System.out.print(" enter your last name=");
	lname=sc.next();
	System.out.print(" enter your passenger id=");
	pid=sc.nextInt();
	System.out.print(" enter your Mobile no=");
	mno=sc.next(); 
	System.out.print(" enter your Destination=");
	dest=sc.next();
	}

	void show(){
		System.out.println("\n "+pid+" "+fname+" "+mname+" "+lname+" "+mno+" "+dest);
	}
	
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	Flight F[]=new Flight[100];
	int ch,ch1,x,id,q,p=0,num=0,flag=0;
	Airline A=new Airline();
	A.intro();
	do
	{
	System.out.println("\n ***********Airline reservation system**********");
	System.out.println(" ==========================our services=========================");
	System.out.println("\n 1:VIEW ALL AVAILABLE FLIGHTS");
	System.out.println(" 2:RESERVE TICKET");
	System.out.println(" 3:CANCEL RESERVATION");
	System.out.println(" 4:RESERVATION LIST");
	System.out.println(" 5:EXIT");
	System.out.print(" enter your choice :");
	ch=sc.nextInt();
	switch(ch)
	{
	case 1:
	System.out.println("\n\n **********Our Top Destinations**************");
	System.out.println(" 1: Canada");
	System.out.println(" 2: England");
	System.out.println(" 3: Germany");
	System.out.println(" 4: South Corea");
	System.out.print(" What is your choice :");
	ch1=sc.nextInt();
	if(ch1==1)
	{
	System.out.println("\n\n Flights for Canada\n");
	System.out.println(" FROM DATE TAKEOUT-TIME LANDING-TIME");
	System.out.println(" INDIA 20-10-20 00:30 11:30");
	System.out.println(" INDIA 23-10-20 06:50 00:55");
	System.out.println(" INDIA 19-11-20 03:45 00:30");
	}
	else if(ch1==2)
	{
	System.out.println("\n\n Flights for England\n");
	System.out.println(" FROM DATE TAKEOUT-TIME LANDING-TIME");
	System.out.println(" INDIA 20-10-20 00:30 11:30");
	System.out.println(" INDIA 23-10-20 06:50 00:55");
	System.out.println(" INDIA 15-11-20 03:45 00:30");
	}
	else if(ch1==3)
	{
	System.out.println("\n\n Flights for Germany\n");
	System.out.println(" FROM DATE TAKEOUT-TIME LANDING-TIME");
	System.out.println(" INDIA 20-10-20 00:30 11:30");
	System.out.println(" INDIA 23-10-20 06:50 00:55");
	System.out.println(" INDIA 07-11-20 03:45 00:30");
	}
	else if(ch1==4)
	{
	System.out.println("\n\n Flights for South Corea\n");
	System.out.println(" FROM DATE TAKEOUT-TIME LANDING-TIME");
	System.out.println(" INDIA 20-10-20 00:30 11:30");
	System.out.println(" INDIA 23-10-20 06:50 00:55");
	System.out.println(" INDIA 03-11-20 03:45 00:30");
	}
	break;
	case 2:
	if (flag==0)
	{
	System.out.println("\n\n *********Enter the details of passenger**************");
	System.out.print("\n\n How many person you want:");
	x=sc.nextInt();
	for(int i=0;i<x;i++)
	{
	F[i]=new Flight();
	}
	for(int i=0;i<x;i++)
	{
		F[i].getdata();
		}
		flag++;
		num=num+x;
		}
		else 
		{
		System.out.println("\n\n **********enter the details of passenger**********");
		System.out.print("\n\n How many person you want=");
		x=sc.nextInt();
		int a=x;
		a=a+num;
		for(int i=num;i<a;i++)
		{
		F[i]=new Flight();
		}
		int i=0;
		i=i+num;
		do
		{
		F[i].getdata();
		i++;
		p++;
		}while(p!=x);
		num=num+x;
		}
		break;
		case 3:
		try
		{
		System.out.print("\n\n enter passenger id to cancel the reservation=");
		id=sc.nextInt();
		int post=0;
		for(int i=0;i<num;i++)
		{
		if(id==F[i].pid)
		{
		post=i+1;
		break;
		}
		}
		if(post==0)
		{
		throw new InvalidException();
		
		}
		else 
		{
		for(int i=post-1;i<num;i++)
		{
		F[i]=F[i+1];
		}
		num--;
		}
		}
		catch(InvalidException e1)
		{
		System.out.print(e1.getMessage());
		}
		break;
		case 4:
		System.out.println(" \n\n **********list of passenger**************");
		System.out.println(" ============================================================");
		System.out.println("\n\n PASS_ID FNAME MNAME LNAME MOB.NO. DESTINATION");
		for(int i=0;i<num;i++)
		{
		F[i].show();
		}
		break;
		case 5:
			break;
			}
			}while(ch!=5);
			}
			


	}


