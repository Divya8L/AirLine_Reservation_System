package Test;

public class Airline {
	public void intro()
	{
	System.out.println("\n\n ===============================================================");
	System.out.println(" *******welcome to railway reservation system********");
	System.out.println(" ===============================================================");
	System.out.println(" \t reserve your seat at our Indian Railway.com");
	}
	
}
